= [SXF] Who View Topic
The Add-on shows who is viewing the topic. The block is at the bottom of the topic.

Плагин показывает кто просматривает тему. Блок находится в низу темы.

![/docs/img/block.png]